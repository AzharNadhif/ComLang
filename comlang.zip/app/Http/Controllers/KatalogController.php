<?php

namespace App\Http\Controllers;

use App\Models\Produk;
use App\Models\Kategori;
use App\Models\Pesanan;
use App\Models\Pembayaran;

class KatalogController extends Controller
{
    public function index()
    {
        $produks = Produk::with('kategori')->get();
        $kategoriCounts = Kategori::withCount('products')->get();
        $totalProduk = $produks->count(); // <-- Tambahkan ini
        return view('shop', compact('produks', 'kategoriCounts', 'totalProduk'));
    }
    
    public function filterByKategori($id_kategori)
    {
        $produks = Produk::with('kategori')->where('id_kategori', $id_kategori)->get();

        return response()->json([
            'data' => $produks
        ]);
    }

    public function show($id)
    {
        $produk = Produk::with('kategori')->findOrFail($id);
        return view('partials.detail-produk', compact('produk'));
    }

    public function checkout(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'alamat' => 'required',
            'no_hp' => 'required',
            'produk_id' => 'required|exists:produks,id',
            'bukti_bayar' => 'required|image|max:2048',
        ]);

        // Ambil harga produk
        $produk = Produk::findOrFail($request->produk_id);

        // Buat pesanan baru
        $pesanan = Pesanan::create([
            'id_user' => auth()->id(), // atau null jika tidak pakai login
            'id_status' => 1, // misal 1 = Menunggu Konfirmasi
            'total' => $produk->harga,
            'tanggal_pesanan' => Carbon::now(),
            'alamat' => $request->alamat,
        ]);

        // Upload bukti bayar
        $path = $request->file('bukti_bayar')->store('bukti_bayar', 'public');

        // Simpan ke tabel pembayaran
        Pembayaran::create([
            'id_pesanan' => $pesanan->id_pesanan,
            'jumlah_bayar' => $produk->harga,
            'bukti_bayar' => $path,
        ]);

        return redirect()->route('shop')->with('success', 'Pemesanan berhasil!');
    }

}
