<?php

namespace App\Http\Controllers;

use App\Models\Pesanan;
use App\Models\Pembayaran;
use App\Models\Produk;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class CheckoutController extends Controller
{
    public function form($id_produk)
    {
        $produk = Produk::findOrFail($id_produk);
        return view('checkout.form', compact('produk'));
    }

    public function proses(Request $request)
    {
        $request->validate([
            'alamat' => 'required|string',
            'bukti_bayar' => 'required|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        $produk = Produk::findOrFail($request->id_produk);

        // Buat pesanan
        $pesanan = Pesanan::create([
            'id_user' => Auth::id(),
            'id_status' => 1, // misalnya 1 = menunggu konfirmasi
            'total' => $produk->harga,
            'tanggal_pesanan' => now(),
            'alamat' => $request->alamat,
        ]);

        // Simpan bukti bayar
        $path = $request->file('bukti_bayar')->store('bukti-bayar', 'public');

        // Simpan pembayaran
        Pembayaran::create([
            'id_pesanan' => $pesanan->id_pesanan,
            'jumlah_bayar' => $produk->harga,
            'bukti_bayar' => $path,
        ]);

        return redirect()->route('shop')->with('success', 'Pesanan berhasil dibuat!');
    }
}

