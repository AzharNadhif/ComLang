@extends('layouts.app')

@section('content')
<div class="container mx-auto py-12 px-4">
    <h1 class="text-2xl font-bold text-center mb-10">Detail Pesanan</h1>

    <div class="grid md:grid-cols-2 gap-10 items-start">
        {{-- Kiri: Produk --}}
        <div class="bg-white rounded-xl shadow p-6">
            <div class="mb-4">
                <span class="bg-red-500 text-white text-sm px-3 py-1 rounded-full">Jersey</span>
            </div>
            <img src="{{ asset('images/produk/' . $produk->gambar) }}" alt="{{ $produk->nama_produk }}" class="w-full rounded-md">
            <h2 class="text-xl font-semibold">{{ $produk->nama_produk }}</h2>
            <p class="text-lg font-medium text-gray-700 mt-2">Rp {{ number_format($produk->harga, 0, ',', '.') }}</p>
        </div>

        {{-- Kanan: Form --}}
        <div class="bg-white rounded-xl shadow p-6">
            <h3 class="text-lg font-semibold mb-4">Informasi Penerima</h3>

            <form action="{{ route('checkout.proses') }}" method="POST" enctype="multipart/form-data" class="space-y-4">
                @csrf
                <input type="hidden" name="id_produk" value="{{ $produk->id_produk }}">

                <div>
                    <label class="block mb-1">Nama Anda:</label>
                    <input type="text" name="nama" class="w-full border rounded px-3 py-2" required>
                </div>

                <div>
                    <label class="block mb-1">Nomor Whatsapp:</label>
                    <input type="text" name="whatsapp" class="w-full border rounded px-3 py-2" required>
                </div>

                <div>
                    <label class="block mb-1">Kode POS:</label>
                    <input type="text" name="kode_pos" class="w-full border rounded px-3 py-2" required>
                </div>

                <div>
                    <label class="block mb-1">Alamat Lengkap:</label>
                    <textarea name="alamat" rows="3" class="w-full border rounded px-3 py-2" required></textarea>
                </div>

                <div class="flex gap-4 pt-4">
                    <button type="submit" class="bg-red-600 text-white px-6 py-2 rounded hover:bg-red-700">Checkout</button>
                    <a href="{{ route('shop') }}" class="border border-red-600 text-red-600 px-6 py-2 rounded hover:bg-red-100">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
