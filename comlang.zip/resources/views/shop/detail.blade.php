@extends('layouts.index') {{-- Sesuaikan dengan layout kamu --}}

@section('content')
<div class="container pt-100 pb-100">
    <div class="row">
        <div class="col-md-6">
            <img src="/images/produk/{{ $produk->gambar }}" alt="{{ $produk->nama_produk }}" class="img-fluid w-100">
        </div>
        <div class="col-md-6">
            <h2>{{ $produk->nama_produk }}</h2>
            <p class="text-muted">Kategori: {{ $produk->kategori->kategori ?? '-' }}</p>
            <h4 class="text-danger mb-3">Rp {{ number_format($produk->harga, 0, ',', '.') }}</h4>

            <p class="mb-3">{{ $produk->deskripsi }}</p>

            <p><strong>Stok:</strong> {{ $produk->stok }}</p>

            <form action="{{ route('checkout', $produk->id) }}" method="POST">
                @csrf
                <input type="hidden" name="produk_id" value="{{ $produk->id }}">
                <button class="btn btn-primary mt-3">Checkout</button>
            </form>
        </div>
    </div>
</div>
@endsection
