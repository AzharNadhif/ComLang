@extends('layouts.app')

@section('content')
<div class="max-w-3xl mx-auto p-6">
    <h1 class="text-2xl font-bold mb-6">Pembayaran</h1>

    <div class="bg-white rounded-lg shadow p-6 mb-6">
        <h2 class="text-lg font-semibold mb-2">Total Pembayaran: <span class="text-red-600">Rp {{ number_format($pesanan->total, 0, ',', '.') }}</span></h2>

        <div class="flex flex-col md:flex-row gap-6">
            <div class="w-full md:w-1/2">
                <img src="{{ asset('assets/qris.jpg') }}" alt="QRIS" class="w-full rounded">
            </div>
            <div class="w-full md:w-1/2">
                <ul class="text-sm mb-4 list-disc list-inside">
                    <li>Metode pembayaran via QRIS (Gopay, OVO, DANA, ShopeePay, dll)</li>
                    <li>Pastikan nominal sesuai total</li>
                    <li>Upload bukti pembayaran setelah transfer</li>
                </ul>

                <form action="{{ route('pembayaran.store', $pesanan->id_pesanan) }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="id_pesanan" value="{{ $pesanan->id_pesanan }}">

                    <div class="mb-4">
                        <label class="block mb-1">Upload Bukti Pembayaran</label>
                        <input type="file" name="bukti_bayar" accept="image/*" class="w-full border p-2 rounded" required>
                    </div>

                    <button type="submit" class="bg-red-500 text-white px-6 py-2 rounded hover:bg-red-600 w-full">Upload Bukti Pembayaran</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
