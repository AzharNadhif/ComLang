@extends('layouts.app')

@section('content')
<div class="max-w-6xl mx-auto p-4">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
            <img src="{{ asset('images/produk/' . $produk->gambar) }}" alt="{{ $produk->nama_produk }}" class="w-full rounded-lg">
        </div>
        <div>
            <span class="bg-red-500 text-white px-3 py-1 rounded text-sm">{{ $produk->kategori->kategori ?? '-' }}</span>
            <h1 class="text-3xl font-bold mt-2">{{ $produk->nama_produk }}</h1>
            <p class="text-xl text-red-600 mt-2">Rp {{ number_format($produk->harga, 0, ',', '.') }}</p><br>
            <a href="{{ route('checkout.show', $produk->id_produk) }}" class="inline-block mt-6 bg-red-500 text-white px-6 py-2 rounded hover:bg-red-600 transition">
                Pesan Sekarang
            </a>
            <br>
            <br>
            <h3 class="text-xl font-bold mt-2" style="margin-bottom: -20px;">Deskripsi Produk</h3>
            <p class="mt-4 text-gray-700">{{ $produk->deskripsi }}</p>
        </div>
    </div>
</div>
@endsection