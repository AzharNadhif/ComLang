<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Comot Langsung</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="manifest" href="site.webmanifest">
		<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
        <!-- Place favicon.ico in the root directory -->

		<!-- CSS here -->

        <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/owl.carousel.min.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/animate.min.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/magnific-popup.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/fontawesome-all.min.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/themify-icons.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/futura-std-font.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/meanmenu.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/swiper-bundle.min.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/slick.css') }}">
         <link rel="stylesheet" href="{{ asset('assets/css/ui.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/responsive.css') }}">
    </head>
    <body>


    <!-- header area start -->
    <header class="header-area">
        <!-- <div class="gota_top bg-soft d-none d-sm-block">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
                            <div class="gota_lang">
                                <ul>
                                    <li><a href="#">usd<i class="fal fa-chevron-down"></i></a>
                                        <ul class="additional_dropdown">
                                            <li><a href="#">euro</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">english<i class="fal fa-chevron-down"></i></a>
                                        <ul class="additional_dropdown">
                                            <li><a href="#">frences</a></li>
                                            <li><a href="#">japanes</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-4 offset-xl-5 col-lg-6 col-md-6 col-sm-6 text-end">
                            <div class="gota_right">
                                <ul>
                                     <li><a href="cart.html">Wishlist</a></li>
                                    <li><a href="login.html">Account</a></li>
                                    <li><a href="checkout.html">Checkout</a></li>
                                    <li><a href="login.html">Login & register</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
        <div class="gota_bottom position-relative">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4 d-none d-sm-block">
                        <div class="gota_cart gotat_cart_1">
                            <a href="javascript:void(0)"><i class="fal fa-user"></i>Profile<span class="counter"></span></a>
                        </div>
                    </div>
                    <div class="col-xl-8 col-lg-8 col-md-4 col-sm-4">
                        <div class="sidemenu sidemenu-1 d-lg-none d-md-block">
                            <a class="open" href="#"><i class="fal fa-bars"></i></a>
                        </div>
                        <div class="main-menu">
                            <nav id="mobile-menu">
                                <ul>
                                    <li><a href="{{ route('home') }}">Home</a></li>
                                    <li><a href="{{ route('shop') }}">Shop</a></li>
                                    <li><a class="d-none d-xl-block" href="{{ route('home') }}">
                                            <img class="pl-50 pr-50" src="{{ asset('assets/img/logo/logoo.png') }}" alt="">
                                        </a>
                                    </li>
                                    <li><a href="{{ route('about') }}">About</a></li>
                                    <li><a href="{{ route('contact') }}">Contact us</a></li>
                                </ul>
                            </nav>
                        </div>
    
                    </div>
                    <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4">
                        <div class="gota_cart gotat_cart_1 text-end">
                            <a href="javascript:void(0)"><i class="fal fa-shopping-cart"></i>My Bag<span class="counter">
                                    (2)</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header area end -->

    <div class="search_area">
        <div class="search_close">
            <span><i class="fal fa-times"></i></span>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12">
                    <div class="search-wrapper text-center">
                        <h2>search</h2>
                        <div class="search-filtering pt-30">
                            <div class="search_tab">
                                <ul class="nav nav-tabs justify-content-center mb-55" id="ffff" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="home-tab2ggg" data-bs-toggle="tab"
                                            data-bs-target="#home2d" type="button" role="tab"
                                            aria-selected="true">All categories</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="profile-tab2ee" data-bs-toggle="tab"
                                            data-bs-target="#profile2d" type="button" role="tab" 
                                            aria-selected="false">Basketball</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" data-bs-toggle="tab"
                                            data-bs-target="#contact2d" type="button" role="tab" 
                                            aria-selected="false">Handbag</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="sportswear-tabff" data-bs-toggle="tab"
                                            data-bs-target="#sportsweard" type="button" role="tab"
                                            aria-selected="false">Sportswear</button>
                                    </li>
                                </ul>
                                <div class="tab-content" id="myTabCffontent2">
                                    <div class="tab-pane fade show active" id="home2d" role="tabpanel"
                                        >
    
                                    </div>
                                    <div class="tab-pane fade" id="profile2d" role="tabpanel"
                                        >
    
                                    </div>
                                    <div class="tab-pane fade" id="contact2d" role="tabpanel">
    
                                    </div>
                                    <div class="tab-pane fade" id="sportsweard" role="tabpanel"
                                        >
    
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="main_search">
                            <form action="#">
                                <input type="text" name="search" placeholder="search products">
                                <button class="m-search"><i class="fal fa-search d-sm-none d-md-block"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>    

    <div class="fix">
        <div class="side-info">
            <button class="side-info-close"><i class="fal fa-times"></i></button>
            <div class="side-info-content">
                <div class="mobile-menu"></div>
                <div class="contact-infos mb-30">
                    <div class="contact-list mb-30">
                        <h4>Office Address</h4>
                        <p>123/A, Miranda City Likaoli
                            Prikano, Dope</p>
                    </div>
                    <div class="contact-list mb-30">
                        <h4>Phone Number</h4>
                        <p>+0989 7876 9865 9</p>
                        <p>+(090) 8765 86543 85</p>
                    </div>
                    <div class="contact-list mb-30">
                        <h4>Email Address</h4>
                        <p>info@example.com</p>
                        <p>example.mail@hum.com</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas-overlay"></div>

  <!-- cart area start  -->
  <div class="cart__sidebar">
    <div class="container">
        <div class="cart__content">
            <div class="cart-text">
                <h3 class="mb-40">Shopping cart</h3>
                <div class="add_cart_product">
                    <div class="add_cart_product__thumb">
                        <img src="./assets/img/product/29-3.jpg" alt="">
                    </div>
                    <div class="add_cart_product__content">
                        <h5><a href="shop.html">Running 3-Stripes</a></h5>
                        <p>1 × $66.00</p>
                        <button class="cart_close"><i class="fal fa-times"></i></button>
                    </div>
                </div>
                <div class="add_cart_product">
                    <div class="add_cart_product__thumb">
                        <img src="./assets/img/product/17.jpg" alt="">
                    </div>
                    <div class="add_cart_product__content">
                        <h5><a href="shop.html">Buddy non Stripes</a></h5>
                        <p>1 × $40.00</p>
                        <button class="cart_close"><i class="fal fa-times"></i></button>
                    </div>
                </div>
            </div>
            <div class="cart-icon">
                <i class="fal fa-times"></i>
            </div>
            <div class="cart-bottom">
                <div class="cart-bottom__text">
                    <span>Subtotal:</span>
                    <span class="end">$121.00</span>
                    <a href="cart.html">view cart</a>
                    <a href="checkout.html">checkout</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="cart-offcanvas-overlay"></div>
<!-- cart area end  -->

    <!-- breadcrumb area start -->
    <div class="page-layout" data-background="assets/img/slider/shop.jpg">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="breadcrumb-area text-center">
                        <h2 class="page-title">shop</h2>
                            <div class="breadcrumb-menu">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb justify-content-center">
                                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                    <li class="breadcrumb-item"><a href="shop.html">shop</a></li>
                                </ol>
                            </nav>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb area end -->

    <!-- shop page start -->
    <div class="shop-page pt-85">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-4 col-md-12">
                    <div class="sidebar">
                        <div class="product-widget">
                            <h3 class="widget-title mb-30">Product categories</h3>
                                <ul class="product-categories">
                                    @foreach($kategoriCounts as $kategori)
                                        <li>
                                            <a href="javascript:void(0)" class="filter-kategori" data-id="{{ $kategori->id_kategori }}">
                                                {{ $kategori->kategori }} <span>({{ $kategori->products_count }})</span>
                                            </a>
                                        </li>
                                    @endforeach
                                </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xl-9 col-lg-8 col-md-9 col-sm-12">
                    <div class="shop-top-bar position-relative">
                        <div class="showing-result">
                            <p id="jumlah-produk">Showing all {{ $totalProduk }} results</p>
                        </div>
                    </div>
<div class="tab-pane fade show active" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
<div class="row" id="produk-container">
    
@foreach ($produks as $produk)
    <div class="col-xl-4">
        <div class="product product-4">
            <div class="product__thumb">
                <a href="{{ route('produk.detail', $produk->id_produk) }}">
                    <img class="product-primary" src="{{ asset('images/produk/' . $produk->gambar) }}" alt="{{ $produk->nama_produk }}" style="width: 100%; height: 300px; object-fit: cover;">
                    <img class="product-secondary" src="{{ asset('images/produk/' . $produk->gambar) }}" alt="{{ $produk->nama_produk }}">
                </a>
                <div class="product-info mb-10">
                    <div class="product_category">
                        <span>{{ $produk->kategori->kategori ?? '-' }}</span>
                    </div>
                </div>
                <div class="product__name">
                    <h4><a href="#">{{ $produk->nama_produk }}</a></h4>
                    <div class="pro-price">
                        <p class="p-absoulute pr-1">Rp {{ number_format($produk->harga, 0, ',', '.') }}</p>
                        <a class="p-absoulute pr-2" href="#">add to cart</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endforeach

                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    </div> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- shop page end -->

    <!-- search area  -->
    <div class="search_area">
        <div class="search_close">
            <span><i class="fal fa-times"></i></span>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12">
                    <div class="search-wrapper text-center">
                        <h2>search</h2>
                        <div class="search-filtering pt-30">
                            <div class="search_tab">
                                <ul class="nav nav-tabs justify-content-center mb-55" id="fff" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="home-tab2" data-bs-toggle="tab"
                                            data-bs-target="#home2" type="button" role="tab" aria-controls="home"
                                            aria-selected="true">All categories</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="profile-tab2" data-bs-toggle="tab"
                                            data-bs-target="#profile2" type="button" role="tab" aria-controls="profile"
                                            aria-selected="false">Basketball</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" data-bs-toggle="tab"
                                            data-bs-target="#contact2" type="button" role="tab" aria-controls="contact"
                                            aria-selected="false">Handbag</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="sportswear-tab" data-bs-toggle="tab"
                                            data-bs-target="#sportswear" type="button" role="tab" aria-controls="sportswear"
                                            aria-selected="false">Sportswear</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="contact3-tab" data-bs-toggle="tab"
                                            data-bs-target="#contact3" type="button" role="tab" aria-controls="contact2"
                                            aria-selected="false">Youth</button>
                                    </li>
                                </ul>
                                <div class="tab-content" id="myTabContent2">
                                    <div class="tab-pane fade show active" id="home2" role="tabpanel"
                                        >

                                    </div>
                                    <div class="tab-pane fade" id="profile2" role="tabpanel"
                                        >

                                    </div>
                                    <div class="tab-pane fade" id="contact2" role="tabpanel">

                                    </div>
                                    <div class="tab-pane fade" id="sportswear" role="tabpanel"
                                        >

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="main_search">
                            <form action="#">
                                <input type="text" name="search" placeholder="search products">
                                <button class="m-search"><i class="fal fa-search d-sm-none d-md-block"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- popup area start -->
    <div class="overlay"></div>
    <div class="product-popup">
            <div class="view-background">
                <div class="row">
                    <div class="col-xl-5 col-lg-5 col-md-5">
                        <div class="quickview">
                            <div class="quickview__thumb">
                                <img src="./assets/img/quick_view/25.jpg" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-7 col-lg-7 col-md-7">
                        <div class="viewcontent">
                            <div class="viewcontent__header">
                              <a href="single.html">  <h2>Brown Leather Bags</h2>
           </a>                     <a class="view_close product-p-close" href="javascript:void(0)"><i class="fal fa-times-circle"></i></a>
                            </div>
                            <div class="viewcontent__rating">
                                <i class="fal fa-star ratingcolor"></i>
                                <i class="fal fa-star ratingcolor"></i>
                                <i class="fal fa-star ratingcolor"></i>
                                <i class="fal fa-star"></i>
                            </div>
                            <div class="viewcontent__price">
                                <h4><span>$</span>99.00</h4>
                            </div>
                            <div class="viewcontent__stock">
                                <h4>Available :<span> In stock</span></h4>
                            </div>
                            <div class="viewcontent__details">
                                <p>Anlor sit amet, consectetur adipiscing elit. Fusce condimentum est lacus, non pretium risus lacinia vel. Fusce eget turpis orci.</p>
                            </div>
                            <div class="viewcontent__action">
                                <span>Qty</span>
                                <span><input type="number" placeholder="1"></span>
                                <span><a href="#">add to cart</a></span>
                                <span><i class="fal fa-heart"></i></span>
                                <span><i class="fal fa-info-circle"></i></span>
                            </div>
                            <div class="viewcontent__footer">
                                <ul>
                                    <li>Category:</li>
                                    <li>SKU:</li>
                                    <li>Brand:</li>
                                </ul>
                                <ul>
                                    <li>Watches</li>
                                    <li>2584-MK63</li>
                                    <li>Brenda</li>  
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    <!-- product popup -->
    <!-- popup area end -->

    <!-- footer area start -->
    <footer class="footer_area fix">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                    <div class="company__info  wow fadeInUp " data-wow-duration=".s" data-wow-delay=".3s">
                        <h3 class="f-title">contact info</h3>
                        <ul>
                            <li>Add: 734 Riverwood Drive, Suite 245 Cottonwood </li>
                            <li>Beverly Hill, Melbourne, USA.</li>
                            <li>Email: Contact@erentheme.com</li>
                            <li>Fax: (+100) 123 456 7890 - (+100) 123 456 7891</li>
                        </ul>
                        <div class="social__media mb-30">
                            <h3 class="f-title">FOLLOW US ON</h3>
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fab fa-google-plus-g"></i></a>
                            <a href="#"><i class="fab fa-dribbble"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-6 col-md-6 col-sm-12">
                    <div class="company__info wow fadeInUp " data-wow-duration=".7s" data-wow-delay=".4s">
                        <h3 class="f-title">Get Help</h3>
                        <ul>
                            <li><a href="contact.html">Contact Us</a></li>
                            <li><a href="accordion.html">Delivery Information</a></li>
                            <li><a href="accordion.html">Sale Terms & Conditions</a></li>
                            <li><a href="accordion.html">Privacy Notice</a></li>
                            <li><a href="accordion.html">Shopping FAQs</a></li>
                            <li><a href="accordion.html">Returns & Refundss</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-6 col-md-6 col-sm-12">
                    <div class="company__info wow fadeInUp " data-wow-duration=".8s" data-wow-delay=".5s">
                        <h3 class="f-title">Popular categories</h3>
                        <ul>
                            <li><a href="shop.html">Sneaker</a></li>
                            <li><a href="shop.html">Clothing & Stools</a></li>
                            <li><a href="shop.html">Helmet for Women’s</a></li>
                            <li><a href="shop.html">Basketball</a></li>
                            <li><a href="shop.html">Mens Running</a></li>
                            <li><a href="shop.html">Footwear</a></li>
                            <li><a href="shop.html">Outerwears</a></li>
                            <li><a href="shop.html">Men’s</a></li>
                            <li><a href="shop.html">Kids & Young</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 offset-xl-1 col-lg-6 col-md-6 col-sm-12">
                    <div class="company__info wow fadeInUp " data-wow-duration=".9s" data-wow-delay=".6s">
                        <h3 class="f-title">get in touch</h3>
                        <p>Sign up for all the news about our latest arrivals and<br>
                            get an exclusive early access shopping. Join <br>
                            <span>60.000+ Subscribers</span> and get a new discount coupon<br> on every Saturday.
                        </p>
                        <div class="subscribe pt-20">
                            <form action="#">
                                <input type="email" placeholder="Enter your email here..." />
                                <button>Subscribe</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer__bottom pb-10 mt-60">
                <div class="row">
                    <div class="col-xl-5 col-lg-5 col-md-6 col-sm-12 ">
                        <p>Copyright © <span>Gota Store</span> All Rights Reserved. Powered by <span><a href="themepure.net">theme_pure</a></span>
                        </p>
                    </div>
                    <div class="col-xl-5 offset-xl-2 col-lg-4 col-md-6 col-sm-12">
                        <div class="footer-menu">
                            <ul class="text-end">
                                <li><a href="contact.html">Site Map</a></li>
                                <li><a href="accordion.html">Search Terms</a></li>
                                <li><a href="shop.html">Advanced Search </a></li>
                                <li><a href="contact.html">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer area end -->


		<!-- JS here -->
        <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
        <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/isotope.pkgd.min.js"></script>
        <script src="assets/js/one-page-nav-min.js"></script>
        <script src="assets/js/slick.min.js"></script>
        <script src="assets/js/jquery.meanmenu.min.js"></script>
        <script src="assets/js/ajax-form.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/jquery.scrollUp.min.js"></script>
        <script src="assets/js/imagesloaded.pkgd.min.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/ui.js"></script>
        <script src="assets/js/swiper-bundle.min.js"></script>
        <script src="assets/js/countdown.js"></script>
        <script src="assets/js/main.js"></script>

       
        <script>
    document.querySelectorAll('.filter-kategori').forEach(item => {
        item.addEventListener('click', function () {
            const id = this.getAttribute('data-id');

            fetch(`/shop/filter/${id}`)
                .then(res => res.json())
                .then(res => {
                    const container = document.querySelector('#produk-container');
                    container.innerHTML = '';

                    res.data.forEach(produk => {
                        container.innerHTML += `
                            <div class="col-xl-4">
                                <div class="product product-4">
                                    <div class="product__thumb">
                                        <a href="#">
                                            <img class="product-primary" src="/images/produk/${produk.gambar}" alt="${produk.nama_produk}">
                                            <img class="product-secondary" src="/images/produk/${produk.gambar}" alt="${produk.nama_produk}">
                                        </a>
                                        <div class="product-info mb-10">
                                            <div class="product_category">
                                                <span>${produk.kategori?.kategori ?? '-'}</span>
                                            </div>
                                        </div>
                                        <div class="product__name">
                                            <h4><a href="#">${produk.nama_produk}</a></h4>
                                            <div class="pro-price">
                                                <p class="p-absoulute pr-1">Rp ${parseInt(produk.harga).toLocaleString('id-ID')}</p>
                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `;
                    });
                });
        });
    });
</script>






    </body>
</html>