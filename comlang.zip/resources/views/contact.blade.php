<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Comot Langsung</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="manifest" href="site.webmanifest">
		<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
        <!-- Place favicon.ico in the root directory -->

		<!-- CSS here -->

        <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/owl.carousel.min.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/animate.min.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/magnific-popup.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/fontawesome-all.min.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/themify-icons.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/futura-std-font.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/meanmenu.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/swiper-bundle.min.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/slick.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/responsive.css') }}">
    </head>
    <body>


    <!-- header area start -->
    <header class="header-area">
        <div class="gota_bottom position-relative">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4 d-none d-sm-block">
                        <div class="gota_cart gotat_cart_1">
                            <a href="javascript:void(0)"><i class="fal fa-user"></i>Profile<span class="counter"></span></a>
                        </div>
                    </div>
                    <div class="col-xl-8 col-lg-8 col-md-4 col-sm-4">
                        <div class="sidemenu sidemenu-1 d-lg-none d-md-block">
                            <a class="open" href="#"><i class="fal fa-bars"></i></a>
                        </div>
                        <div class="main-menu">
                            <nav id="mobile-menu">
                                <ul>
                                    <li><a href="{{ route('home') }}">Home</a></li>
                                    <li><a href="{{ route('shop') }}">Shop</a></li>
                                    <li><a class="d-none d-xl-block" href="{{ route('home') }}">
                                            <img class="pl-50 pr-50" src="{{ asset('assets/img/logo/logoo.png') }}" alt="">
                                        </a>
                                    </li>
                                    <li><a href="{{ route('about') }}">About</a></li>
                                    <li><a href="{{ route('contact') }}">Contact us</a></li>
                                </ul>
                            </nav>
                        </div>
    
                    </div>
                    <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4">
                        <div class="gota_cart gotat_cart_1 text-end">
                            <a href="javascript:void(0)"><i class="fal fa-shopping-cart"></i>My Bag<span class="counter">
                                    (2)</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header area end -->

    <div class="search_area">
        <div class="search_close">
            <span><i class="fal fa-times"></i></span>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12">
                    <div class="search-wrapper text-center">
                        <h2>search</h2>
                        <div class="search-filtering pt-30">
                            <div class="search_tab">
                                <ul class="nav nav-tabs justify-content-center mb-55" id="myTab2" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="home-tab2" data-bs-toggle="tab"
                                            data-bs-target="#home2" type="button" role="tab"
                                            aria-selected="true">All categories</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="profile-tab2" data-bs-toggle="tab"
                                            data-bs-target="#profile2" type="button" role="tab" 
                                            aria-selected="false">Basketball</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" data-bs-toggle="tab"
                                            data-bs-target="#contact2" type="button" role="tab" 
                                            aria-selected="false">Handbag</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="sportswear-tab" data-bs-toggle="tab"
                                            data-bs-target="#sportswear" type="button" role="tab"
                                            aria-selected="false">Sportswear</button>
                                    </li>
                                </ul>
                                <div class="tab-content" id="myTabContent2">
                                    <div class="tab-pane fade show active" id="home2" role="tabpanel"
                                        >
    
                                    </div>
                                    <div class="tab-pane fade" id="profile2" role="tabpanel"
                                        >
    
                                    </div>
                                    <div class="tab-pane fade" id="contact2" role="tabpanel">
    
                                    </div>
                                    <div class="tab-pane fade" id="sportswear" role="tabpanel"
                                        >
    
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="main_search">
                            <form action="#">
                                <input type="text" name="search" placeholder="search products">
                                <button class="m-search"><i class="fal fa-search d-sm-none d-md-block"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="fix">
        <div class="side-info">
            <button class="side-info-close"><i class="fal fa-times"></i></button>
            <div class="side-info-content">
                <div class="mobile-menu"></div>
                <div class="contact-infos mb-30">
                    <div class="contact-list mb-30">
                        <h4>Office Address</h4>
                        <p>123/A, Miranda City Likaoli
                            Prikano, Dope</p>
                    </div>
                    <div class="contact-list mb-30">
                        <h4>Phone Number</h4>
                        <p>+0989 7876 9865 9</p>
                        <p>+(090) 8765 86543 85</p>
                    </div>
                    <div class="contact-list mb-30">
                        <h4>Email Address</h4>
                        <p>info@example.com</p>
                        <p>example.mail@hum.com</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas-overlay"></div>

  <!-- cart area start  -->
  <div class="cart__sidebar">
    <div class="container">
        <div class="cart__content">
            <div class="cart-text">
                <h3 class="mb-40">Shopping cart</h3>
                <div class="add_cart_product">
                    <div class="add_cart_product__thumb">
                        <img src="./assets/img/product/29-3.jpg" alt="">
                    </div>
                    <div class="add_cart_product__content">
                        <h5><a href="shop.html">Running 3-Stripes</a></h5>
                        <p>1 × $66.00</p>
                        <button class="cart_close"><i class="fal fa-times"></i></button>
                    </div>
                </div>
                <div class="add_cart_product">
                    <div class="add_cart_product__thumb">
                        <img src="./assets/img/product/17.jpg" alt="">
                    </div>
                    <div class="add_cart_product__content">
                        <h5><a href="shop.html">Buddy non Stripes</a></h5>
                        <p>1 × $40.00</p>
                        <button class="cart_close"><i class="fal fa-times"></i></button>
                    </div>
                </div>
            </div>
            <div class="cart-icon">
                <i class="fal fa-times"></i>
            </div>
            <div class="cart-bottom">
                <div class="cart-bottom__text">
                    <span>Subtotal:</span>
                    <span class="end">$121.00</span>
                    <a href="cart.html">view cart</a>
                    <a href="checkout.html">checkout</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="cart-offcanvas-overlay"></div>
<!-- cart area end  -->

    <!-- contact area start -->
    <div class="contact__area">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12">
                <div class="contact__content text-center mb-140">
                    <h2>Contact Us</h2>
                    <p>For me, the most important part of improving at photography has been sharing it. Sign up for an Exposure account, or<br> post regularly to Tumblr, or both. Tell people you’re trying to get better at photography. </p>
                </div>
                </div>
            </div>
            <div class="contact-wrapper">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-6">
                    <div class="contactbox">
                        <div class="contactbox__heading">
                            <h5>Contact us</h5>
                            <h2>Please contact us quickly if <br>you need help.</h2>
                        </div>
                        <div class="contactbox__info pt-20">
                            <h5>NewYork Add:</h5>
                            <ul>
                                <li>S9 Heaven Stress, Beverly Hill, Melbourne, USA.</li>
                                <li>Open: 9:30 am – 9:00 pm</li>
                            </ul>
                        </div>
                        <div class="contactbox__info pt-20">
                            <h5>London</h5>
                            <ul>
                                <li>S9 Heaven Stress, Beverly Hill, Melbourne, USA.</li>
                                <li>Open: 9:30 am – 9:00 pm</li>
                            </ul>
                        </div>
                        <div class="contactbox__info pt-20">
                            <h5>Contacts Email:</h5>
                            <ul>
                                <li>Agota@erentheme.com Phone</li>
                                <li><a href="tel:(+100)123456789">(+100) 123 456 789</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-12 col-md-6">
                    <div class="form">
                        <h5>write to us</h5>
                        <form action="#" method="POST">
                            <div class="c-input-group">
                                <label>Your Email (required)</label>
                                <input type="text">
                            </div>
                            <div class="c-input-group">
                                <label>Subject</label>
                                <input type="text">
                            </div>
                            <div class="c-input-group">
                                <label>Your Message</label>
                                <textarea name="message" ></textarea>
                            </div>
                            <div class="submit-btn">
                                <input type="submit" value="Send">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
     <!-- contact area end -->

         <div class="map__area">
            <div class="google-map contact-map">
                <iframe class="w-100" height="800" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3986.0999515452136!2d106.76122151057005!3d-6.336152593627073!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69efa999f334e7%3A0xd0ce5831591c54dd!2sPondok%20Cabe%20Airport!5e1!3m2!1sen!2sid!4v1745222372503!5m2!1sen!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
         </div>

    <!-- footer area start -->
    <footer class="footer_area fix">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                    <div class="company__info  wow fadeInUp " data-wow-duration=".s" data-wow-delay=".3s">
                        <h3 class="f-title">contact info</h3>
                        <ul>
                            <li>Add: 734 Riverwood Drive, Suite 245 Cottonwood </li>
                            <li>Beverly Hill, Melbourne, USA.</li>
                            <li>Email: Contact@erentheme.com</li>
                            <li>Fax: (+100) 123 456 7890 - (+100) 123 456 7891</li>
                        </ul>
                        <div class="social__media mb-30">
                            <h3 class="f-title">FOLLOW US ON</h3>
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fab fa-google-plus-g"></i></a>
                            <a href="#"><i class="fab fa-dribbble"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-6 col-md-6 col-sm-12">
                    <div class="company__info wow fadeInUp " data-wow-duration=".7s" data-wow-delay=".4s">
                        <h3 class="f-title">Get Help</h3>
                        <ul>
                            <li><a href="contact.html">Contact Us</a></li>
                            <li><a href="accordion.html">Delivery Information</a></li>
                            <li><a href="accordion.html">Sale Terms & Conditions</a></li>
                            <li><a href="accordion.html">Privacy Notice</a></li>
                            <li><a href="accordion.html">Shopping FAQs</a></li>
                            <li><a href="accordion.html">Returns & Refundss</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-6 col-md-6 col-sm-12">
                    <div class="company__info wow fadeInUp " data-wow-duration=".8s" data-wow-delay=".5s">
                        <h3 class="f-title">Popular categories</h3>
                        <ul>
                            <li><a href="shop.html">Sneaker</a></li>
                            <li><a href="shop.html">Clothing & Stools</a></li>
                            <li><a href="shop.html">Helmet for Women’s</a></li>
                            <li><a href="shop.html">Basketball</a></li>
                            <li><a href="shop.html">Mens Running</a></li>
                            <li><a href="shop.html">Footwear</a></li>
                            <li><a href="shop.html">Outerwears</a></li>
                            <li><a href="shop.html">Men’s</a></li>
                            <li><a href="shop.html">Kids & Young</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 offset-xl-1 col-lg-6 col-md-6 col-sm-12">
                    <div class="company__info wow fadeInUp " data-wow-duration=".9s" data-wow-delay=".6s">
                        <h3 class="f-title">get in touch</h3>
                        <p>Sign up for all the news about our latest arrivals and<br>
                            get an exclusive early access shopping. Join <br>
                            <span>60.000+ Subscribers</span> and get a new discount coupon<br> on every Saturday.
                        </p>
                        <div class="subscribe pt-20">
                            <form action="#">
                                <input type="email" placeholder="Enter your email here..." />
                                <button>Subscribe</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer__bottom pb-10 mt-60">
                <div class="row">
                    <div class="col-xl-5 col-lg-5 col-md-6 col-sm-12 ">
                        <p>Copyright © <span>Gota Store</span> All Rights Reserved. Powered by <span><a href="themepure.net">theme_pure</a></span>
                        </p>
                    </div>
                    <div class="col-xl-5 offset-xl-2 col-lg-4 col-md-6 col-sm-12">
                        <div class="footer-menu">
                            <ul class="text-end">
                                <li><a href="contact.html">Site Map</a></li>
                                <li><a href="accordion.html">Search Terms</a></li>
                                <li><a href="shop.html">Advanced Search </a></li>
                                <li><a href="contact.html">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer area end -->


		<!-- JS here -->
        <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
        <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/isotope.pkgd.min.js"></script>
        <script src="assets/js/one-page-nav-min.js"></script>
        <script src="assets/js/slick.min.js"></script>
        <script src="assets/js/jquery.meanmenu.min.js"></script>
        <script src="assets/js/ajax-form.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/jquery.scrollUp.min.js"></script>
        <script src="assets/js/imagesloaded.pkgd.min.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/swiper-bundle.min.js"></script>
        <script src="assets/js/countdown.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
</html>