<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Comot Langsung</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="manifest" href="site.webmanifest">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/owl.carousel.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/animate.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/magnific-popup.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/fontawesome-all.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/themify-icons.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/futura-std-font.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/meanmenu.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/swiper-bundle.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/slick.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/responsive.css') }}">
</head>

<body>

    <!-- header area start -->
    <header class="header-area">
        <div class="gota_bottom position-relative">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4 d-none d-sm-block">
                        <div class="gota_cart gotat_cart_1">
                            <a href="javascript:void(0)"><i class="fal fa-user"></i>Profile<span class="counter"></span></a>
                        </div>
                    </div>
                    <div class="col-xl-8 col-lg-8 col-md-4 col-sm-4">
                        <div class="sidemenu sidemenu-1 d-lg-none d-md-block">
                            <a class="open" href="#"><i class="fal fa-bars"></i></a>
                        </div>
                        <div class="main-menu">
                            <nav id="mobile-menu">
                                <ul>
                                    <li><a href="{{ route('home') }}">Home</a></li>
                                    <li><a href="{{ route('shop') }}">Shop</a></li>
                                    <li><a class="d-none d-xl-block" href="{{ route('home') }}">
                                            <img class="pl-50 pr-50" src="{{ asset('assets/img/logo/logoo.png') }}" alt="">
                                        </a>
                                    </li>
                                    <li><a href="{{ route('about') }}">About</a></li>
                                    <li><a href="{{ route('contact') }}">Contact us</a></li>
                                </ul>
                            </nav>
                        </div>

                    </div>
                    <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4">
                        <div class="gota_cart gotat_cart_1 text-end">
                            <a href="javascript:void(0)"><i class="fal fa-shopping-cart"></i>My Bag<span class="counter"> (2)</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header area end -->

    <div class="search_area">
        <div class="search_close">
            <span><i class="fal fa-times"></i></span>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12">
                    <div class="search-wrapper text-center">
                        <h2>search</h2>
                        <div class="search-filtering pt-30">
                            <div class="search_tab">
                                <ul class="nav nav-tabs justify-content-center mb-55" id="myTab2" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="home-tab2" data-bs-toggle="tab"
                                            data-bs-target="#home2" type="button" role="tab"
                                            aria-selected="true">All categories</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="profile-tab2" data-bs-toggle="tab"
                                            data-bs-target="#profile2" type="button" role="tab" 
                                            aria-selected="false">Basketball</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" data-bs-toggle="tab"
                                            data-bs-target="#contact2" type="button" role="tab" 
                                            aria-selected="false">Handbag</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="sportswear-tab" data-bs-toggle="tab"
                                            data-bs-target="#sportswear" type="button" role="tab"
                                            aria-selected="false">Sportswear</button>
                                    </li>
                                </ul>
                                <div class="tab-content" id="myTabContent2">
                                    <div class="tab-pane fade show active" id="home2" role="tabpanel"
                                        >
    
                                    </div>
                                    <div class="tab-pane fade" id="profile2" role="tabpanel"
                                        >
    
                                    </div>
                                    <div class="tab-pane fade" id="contact2" role="tabpanel">
    
                                    </div>
                                    <div class="tab-pane fade" id="sportswear" role="tabpanel"
                                        >
    
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="main_search">
                            <form action="#">
                                <input type="text" name="search" placeholder="search products">
                                <button class="m-search"><i class="fal fa-search d-sm-none d-md-block"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="fix">
        <div class="side-info">
            <button class="side-info-close"><i class="fal fa-times"></i></button>
            <div class="side-info-content">
                <div class="mobile-menu"></div>
                <div class="contact-infos mb-30">
                    <div class="contact-list mb-30">
                        <h4>Office Address</h4>
                        <p>123/A, Miranda City Likaoli
                            Prikano, Dope</p>
                    </div>
                    <div class="contact-list mb-30">
                        <h4>Phone Number</h4>
                        <p>+0989 7876 9865 9</p>
                        <p>+(090) 8765 86543 85</p>
                    </div>
                    <div class="contact-list mb-30">
                        <h4>Email Address</h4>
                        <p>info@example.com</p>
                        <p>example.mail@hum.com</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas-overlay"></div>

  <!-- cart area start  -->
  <div class="cart__sidebar">
    <div class="container">
        <div class="cart__content">
            <div class="cart-text">
                <h3 class="mb-40">Shopping cart</h3>
                <div class="add_cart_product">
                    <div class="add_cart_product__thumb">
                        <img src="./assets/img/product/29-3.jpg" alt="">
                    </div>
                    <div class="add_cart_product__content">
                        <h5><a href="shop.html">Running 3-Stripes</a></h5>
                        <p>1 × $66.00</p>
                        <button class="cart_close"><i class="fal fa-times"></i></button>
                    </div>
                </div>
                <div class="add_cart_product">
                    <div class="add_cart_product__thumb">
                        <img src="./assets/img/product/17.jpg" alt="">
                    </div>
                    <div class="add_cart_product__content">
                        <h5><a href="shop.html">Buddy non Stripes</a></h5>
                        <p>1 × $40.00</p>
                        <button class="cart_close"><i class="fal fa-times"></i></button>
                    </div>
                </div>
            </div>
            <div class="cart-icon">
                <i class="fal fa-times"></i>
            </div>
            <div class="cart-bottom">
                <div class="cart-bottom__text">
                    <span>Subtotal:</span>
                    <span class="end">$121.00</span>
                    <a href="cart.html">view cart</a>
                    <a href="checkout.html">checkout</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="cart-offcanvas-overlay"></div>
<!-- cart area end  -->

    <!-- slider start -->
    <div class="slider-active swiper-container height">
        <div class="swiper-wrapper">
            <div class="swiper-slide slider-item">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="slider_images">
                                <img class="back" src="./assets/img/slider/cb.png" alt="">
                                <img class="top" src="./assets/img/slider/text.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide slider-item">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="slider_images">
                                <img class="back" src="./assets/img/slider/cbb.png" alt="">
                                <img class="top" src="./assets/img/slider/text.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-slide slider-item">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="slider_images">
                                <img class="back" src="./assets/img/slider/coba.png" alt="">
                                <img class="top" src="./assets/img/slider/text.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
    </div>
    <!-- slider end -->

    <!-- features area start  -->
    <div class="features-area d-none d-md-block fix">
        <div class="row g-0">
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <div class="fetures">
                    <div class="fetures__thumb fix">
                        <a href="shop.html"><img src="./assets/img/features/coba.png" alt="features1"></a>
                    </div>
                    <div class="fetures__content">
                        <h4 class="feature-title mb-40">Sport<br> Baseball</h4>
                        <p class="d-md-none d-lg-block">all products <span class="discount"><a href="#">up to 70%
                                    off</a></span> limited time discount</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <div class="fetures">
                    <div class="fetures__thumb fix">
                        <a href="shop.html"><img src="./assets/img/features/coba.png" alt="features1"></a>
                    </div>
                    <div class="fetures__content pt-200">
                        <p class="d-md-none d-lg-block">Gota store with a tool that makes design simple for everyone</p>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <div class="fetures">
                    <div class="fetures__thumb fix">
                        <a href="shop.html"><img src="./assets/img/features/coba.png" alt="features1"></a>
                    </div>
                    <div class="fetures__content">
                        <h4 class="feature-title mb-40">Jacket<br>For women’s</h4>
                        <p class="d-md-none d-lg-block">all products <span class="discount"><a href="#">up to 70%
                                    off</a></span> limited time discount</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- features area end  -->

    <!-- product show case area start  -->
    <div class="show-case lightblue pt-125">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="section-wrapper text-center mb-35">
                        <h4 class="sub-title">Bestseller products</h4>
                        <h2 class="section-title text-white">Nike Air Force 1 Sage Low LX</h2>
                        <p class="d-none d-lg-block">Commodo sociosqu venenatis cras dolor sagittis integer luctus sem
                            primis<br> eget maecenas sed urna malesuada.</p>
                    </div>
                </div>
                <div class="case-info text-center">
                    <span class="offer-text d-none d-lg-block">hot deal<i class="far fa-stars"></i></span>
                    <h2 class="back1-text d-none d-lg-block">top</h2>
                    <h2 class="back-text d-none d-lg-block">limited</h2>
                    <a href="shop.html"><img class="banar-product" src="./assets/img/product/coba.png" alt=""></a>
                </div>
            </div>
        </div>
    </div>
    <!-- product show case area end  -->

    <!-- categories area start -->
    <div class="categories_area pt-85 mb-150">
        <div class="container-fluid">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="section-wrapper text-center mb-35">
                    <h2 class="section-title">Explore Our Bestsellers</h2>
                    <p>Commodo sociosqu venenatis cras dolor sagittis integer luctus sem primis<br> eget maecenas sed urna
                        malesuada.</p>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="categories__tab">
                        <ul class="nav nav-tabs justify-content-center mb-55" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home"
                                    type="button" role="tab" aria-selected="true">All</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile"
                                    type="button" role="tab" aria-selected="false">Jersey</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact"
                                    type="button" role="tab" aria-selected="false">Outer</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#kidss" type="button"
                                    role="tab" aria-selected="false">T-Shirt</button>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home">
                                <div class="container">
                                    <div class="product-active h-2-product-active swiper-container">
                                        <div class="swiper-wrapper">
                                            <div class="product-item swiper-slide wow fadeInUp" data-wow-duration="1s"
                                                data-wow-delay="0.2s">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/9-2.jpg"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/9-2.jpg" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Kaos</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">Kaos Vintage Anjay</a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>Rp.</span>200.000</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide wow fadeInUp" data-wow-duration="1s"
                                                data-wow-delay="0.4s">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary"
                                                                src="./assets/img/product/hoodie.jpg" alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/hoodie.jpg" alt="product_image">
                                                        </a>
                                                        <!-- <div class="product__update">
                                                                    <a class="#">new</a>
                                                                </div> -->
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Hoodie</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">Hoodie Tengkorak Monyet</a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>Rp.</span>800.000</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide wow fadeInUp" data-wow-duration="1s"
                                                data-wow-delay="0.6s">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cb.png"
                                                                alt="product_image">
                                                            <img class="product-secondary" src="./assets/img/product/cb.png"
                                                                alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Jersey</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">Jersey indo vintage kece beut dah</a>
                                                            </h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>Rp.</span>1.000.000</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide wow fadeInUp" data-wow-duration="1s"
                                                data-wow-delay="0.8s">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/4.jpg"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/4-2.jpg" alt="product_image">
                                                        </a>
                                                        <!-- <div class="product__update">
                                                                    <a class="#">new</a>
                                                                </div> -->
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">Running Shoes for Men</a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>70.00 -
                                                                    <span>$</span>60.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide wow fadeInUp" data-wow-duration="1s"
                                                data-wow-delay="1s">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/10.jpg"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/10-2.jpg" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">Lotto Flip-Flop Sports Slippers</a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide wow fadeInUp" data-wow-duration="1s"
                                                data-wow-delay="0.2s">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat1.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat2.png" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">aestro 700 Turf Soccer Cleats</a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>360.00 -
                                                                    <span>$</span>260.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
    
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="profile">
                                <div class="container">
                                    <div class="product-active swiper-container">
                                        <div class="swiper-wrapper">
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat1.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat2.png" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating text-end">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="single.html">Sports Sandals for </a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>180.00 -
                                                                    <span>$</span>880.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat2.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat1.png" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="lightblueclr" href="#">-20%</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">Sports Sandals for </a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>180.00 -
                                                                    <span>$</span>980.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat3.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat2.png" alt="product_image">
                                                        </a>
                                                        <!-- <div class="product__update">
                                                                    <a class="#">new</a>
                                                                </div> -->
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">and American foreign trade </a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>280.00 -
                                                                    <span>$</span>580.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat2.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat2.png" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="lightblueclr" href="#">-30%</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">Korean version of women's platform</a>
                                                            </h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>480.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat1.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat2.png" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">new word with thick toes and </a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat1.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat2.png" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">High-heeled sandals women 2021 </a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
    
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="contact">
                                <div class="container">
                                    <div class="product-active h-2-product-active swiper-container">
                                        <div class="swiper-wrapper">
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/9.jpg"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/9-2.jpg" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">women's sandals stiletto super </a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/3.jpg"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/3-2.jpg" alt="product_image">
                                                        </a>
                                                        <!-- <div class="product__update">
                                                                    <a class="#">new</a>
                                                                </div> -->
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">Women's 2021 new balance heel </a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/11.jpg"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/11-2.jpg" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">big silk belt female sandals</a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/4.jpg"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/4-2.jpg" alt="product_image">
                                                        </a>
                                                        <!-- <div class="product__update">
                                                                    <a class="#">new</a>
                                                                </div> -->
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">heeled big silk belt female sandals</a>
                                                            </h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/10.jpg"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/10-2.jpg" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">Fashion high heeled big silk belt </a>
                                                            </h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat1.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat2.png" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">balance heel summer new platfh </a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
    
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="kidss">
                                <div class="container">
                                    <div class="product-active swiper-container">
                                        <div class="swiper-wrapper">
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat1.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat2.png" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating text-end">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="single.html">heeled big silk belt </a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat2.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat1.png" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="lightblueclr" href="#">-20%</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">d American style Roman </a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat3.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat2.png" alt="product_image">
                                                        </a>
                                                        <!-- <div class="product__update">
                                                                    <a class="#">new</a>
                                                                </div> -->
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">stiletto high-heeled thin shallow </a>
                                                            </h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat2.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat2.png" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="lightblueclr" href="#">-30%</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">high-heeled thin shallow </a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat1.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat2.png" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">Fashion high heeled big silk belt </a>
                                                            </h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-item swiper-slide">
                                                <div class="product">
                                                    <div class="product__thumb">
                                                        <a href="single.html">
                                                            <img class="product-primary" src="./assets/img/product/cat1.png"
                                                                alt="product_image">
                                                            <img class="product-secondary"
                                                                src="./assets/img/product/cat2.png" alt="product_image">
                                                        </a>
                                                        <div class="product__update">
                                                            <a class="#">new</a>
                                                        </div>
                                                        <div class="product-info mb-10">
                                                            <div class="product_category">
                                                                <span>Shoes, Clothing</span>
                                                            </div>
                                                            <div class="product_rating">
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star start-color"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                                <a href="#"><i class="fal fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="product__name">
                                                            <h4><a href="shop.html">heeled sandals open</a></h4>
                                                            <div class="pro-price">
                                                                <p class="p-absoulute pr-1"><span>$</span>680.00 -
                                                                    <span>$</span>680.00</p>
                                                                <a class="p-absoulute pr-2" href="#">add to cart</a>
                                                            </div>
                                                        </div>
                                                        <div class="product__action">
                                                            <div class="inner__action">
                                                                <div class="wishlist">
                                                                    <a href="#"><i class="fal fa-heart"></i></a>
                                                                </div>
                                                                <div class="view">
                                                                    <a href="javascript:void(0)"><i
                                                                            class="fal fa-eye"></i></a>
                                                                </div>
                                                                <div class="layer">
                                                                    <a href="#"><i class="fal fa-layer-group"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
    
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- categories area end -->

    <!-- new product area start -->
    <div class="new_product_area mb-80">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <div class="section-wrapper text-center mb-35">
                                <h2 class="section-title"><a href="#">Explore Our New arrivals</a></h2>
                                <p>Commodo sociosqu venenatis cras dolor sagittis integer luctus sem primis<br> eget
                                    maecenas sed urna malesuada.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 padding-left">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12"></div>
                    <div class="section-wrapper text-center mb-35">
                        <h2 class="section-title">Explore Our featured</h2>
                        <p>Commodo sociosqu venenatis cras dolor sagittis integer luctus sem primis<br> eget maecenas
                            sed urna malesuada.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- new product area end -->

    <!-- popup area start -->
    <div class="overlay"></div>
    <div class="product-popup">
        <div class="view-background">
            <div class="row">
                <div class="col-xl-5 col-lg-5 col-md-5">
                    <div class="quickview">
                        <div class="quickview__thumb">
                            <img src="./assets/img/quick_view/25.jpg" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-7 col-md-7">
                    <div class="viewcontent">
                        <div class="viewcontent__header">
                            <h2>Brown Leather Bags</h2>
                            <a class="view_close product-p-close" href="javascript:void(0)"><i
                                    class="fal fa-times-circle"></i></a>
                        </div>
                        <div class="viewcontent__rating">
                            <i class="fal fa-star ratingcolor"></i>
                            <i class="fal fa-star ratingcolor"></i>
                            <i class="fal fa-star ratingcolor"></i>
                            <i class="fal fa-star"></i>
                        </div>
                        <div class="viewcontent__price">
                            <h4><span>$</span>99.00</h4>
                        </div>
                        <div class="viewcontent__stock">
                            <h4>Available :<span> In stock</span></h4>
                        </div>
                        <div class="viewcontent__details">
                            <p>Anlor sit amet, consectetur adipiscing elit. Fusce condimentum est lacus, non pretium
                                risus lacinia vel. Fusce eget turpis orci.</p>
                        </div>
                        <div class="viewcontent__action">
                            <span>Qty</span>
                            <span><input type="number" placeholder="1"></span>
                            <span><a href="#">add to cart</a></span>
                            <span><i class="fal fa-heart"></i></span>
                            <span><i class="fal fa-info-circle"></i></span>
                        </div>
                        <div class="viewcontent__footer">
                            <ul>
                                <li>Category:</li>
                                <li>SKU:</li>
                                <li>Brand:</li>
                            </ul>
                            <ul>
                                <li>Watches</li>
                                <li>2584-MK63</li>
                                <li>Brenda</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- popup area end -->

    <!-- footer area start -->
    <footer class="footer_area fix">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                    <div class="company__info  wow fadeInUp " data-wow-duration=".s" data-wow-delay=".3s">
                        <h3 class="f-title">contact info</h3>
                        <ul>
                            <li>Pondok Cabe, Tangerang Selatan </li>
                            <li>Email: comotlangsung@gmail.com</li>
                            <li>Fax: (+62) 896 5490 2861</li>
                        </ul>
                        <div class="social__media mb-30">
                            <h3 class="f-title">FOLLOW US ON</h3>
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.instagram.com/comotlangsung/"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fab fa-google-plus-g"></i></a>
                            <a href="#"><i class="fab fa-dribbble"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-6 col-md-6 col-sm-12">
                    <div class="company__info wow fadeInUp " data-wow-duration=".7s" data-wow-delay=".4s">
                        <h3 class="f-title">Get Help</h3>
                        <ul>
                            <li><a href="contact.html">Contact Us</a></li>
                            <li><a href="accordion.html">Delivery Information</a></li>
                            <li><a href="accordion.html">Sale Terms & Conditions</a></li>
                            <li><a href="accordion.html">Privacy Notice</a></li>
                            <li><a href="accordion.html">Shopping FAQs</a></li>
                            <li><a href="accordion.html">Returns & Refundss</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-6 col-md-6 col-sm-12">
                    <div class="company__info wow fadeInUp " data-wow-duration=".8s" data-wow-delay=".5s">
                        <h3 class="f-title">Popular categories</h3>
                        <ul>
                            <li><a href="shop.html">Sneaker</a></li>
                            <li><a href="shop.html">Clothing & Stools</a></li>
                            <li><a href="shop.html">Helmet for Women’s</a></li>
                            <li><a href="shop.html">Basketball</a></li>
                            <li><a href="shop.html">Mens Running</a></li>
                            <li><a href="shop.html">Footwear</a></li>
                            <li><a href="shop.html">Outerwears</a></li>
                            <li><a href="shop.html">Men’s</a></li>
                            <li><a href="shop.html">Kids & Young</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 offset-xl-1 col-lg-6 col-md-6 col-sm-12">
                    <div class="company__info wow fadeInUp " data-wow-duration=".9s" data-wow-delay=".6s">
                        <h3 class="f-title">get in touch</h3>
                        <p>Sign up for all the news about our latest arrivals and<br>
                            get an exclusive early access shopping. Join <br>
                            <span>60.000+ Subscribers</span> and get a new discount coupon<br> on every Saturday.
                        </p>
                        <div class="subscribe pt-20">
                            <form action="#">
                                <input type="email" placeholder="Enter your email here..." />
                                <button>Subscribe</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer__bottom pb-10 mt-60">
                <div class="row">
                    <div class="col-xl-5 col-lg-5 col-md-6 col-sm-12 ">
                        <p>Copyright © <span>Comot Langsung</span> All Rights Reserved. Powered by <span><a href="https://www.instagram.com/einsteiniumproject/">einsteinium</a></span>
                        </p>
                    </div>
                    <div class="col-xl-5 offset-xl-2 col-lg-4 col-md-6 col-sm-12">
                        <div class="footer-menu">
                            <ul class="text-end">
                                <li><a href="contact.html">Site Map</a></li>
                                <li><a href="accordion.html">Search Terms</a></li>
                                <li><a href="shop.html">Advanced Search </a></li>
                                <li><a href="contact.html">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer area end -->


    <!-- JS here -->
    <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/one-page-nav-min.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <script src="assets/js/jquery.meanmenu.min.js"></script>
    <script src="assets/js/countdown.js"></script>
    <script src="assets/js/ajax-form.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/jquery.scrollUp.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>